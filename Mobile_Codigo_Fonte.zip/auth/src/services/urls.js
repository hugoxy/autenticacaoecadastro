export const BASE_URL = 'http://victorgontijo-001-site1.htempurl.com';
