import React from 'react';
import { StyleSheet } from 'react-native';
import { TextInput } from 'react-native-paper';

const Header = (props) => {
  return (
      <TextInput 
        style={styles.input}  
        mode="outlined"
        {...props}  
      />)
    ;
};

const styles = StyleSheet.create({
  input: {
    backgroundColor: 'grey',
    marginBottom: 8,
    marginHorizontal: '10%',
    paddingVertical: 1,
    fontWeight: 'bold',
    height: 40,
    width: '80%'
  },
});



export default Header;