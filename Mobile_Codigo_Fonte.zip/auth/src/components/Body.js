import React from 'react';
import {StyleSheet, View} from 'react-native';

const Body = ({children}) =>{
  return <View style={styles.container}>{children}</View>
};

const styles = StyleSheet.create({
 container:{
    flex:2,
    backgroundColor: '#D3D3D3',
    margin:2,
  },
});

export default Body;