import React, {useState} from 'react';
import { View, Text } from 'react-native-paper';


const Home = () => {
  const [index, setIndex] = useState(0);
  
  return (
    <View>
    </View>
  );
};

export default Home;