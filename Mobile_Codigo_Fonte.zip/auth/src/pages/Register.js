import React, { useState, Component } from 'react';
import { StyleSheet, View, Alert, TouchableOpacity} from 'react-native';
import { Text,TextInput, Button, Headline,RadioButton, Divider, Provider, Menu} from 'react-native-paper';
import Container from '../components/Container';
import Body from '../components/Body';
import Input from '../components/Input';

import { useNavigation } from '@react-navigation/native';


import {register} from '../services/auth.services';

import moment from 'moment';
import DateTimePicker from '@react-native-community/datetimepicker';

const Register = () => {

  const navigation = useNavigation();
  
  const [name, setName] = useState();
  const [email, setEmail] = useState();
  const [genero, setGenero] = useState('feminino');
  const [lgpd, setLgpd] = useState(false);

  const [role, setRole] = useState();


  const [password, setPassword] = useState();
  const [hidePass, setHidePass] = useState(true);
  
  const [data, setData] = useState(moment(new Date()).format('DD/MM/YYYY'));
  const [date, setDate] = useState(new Date());
  const [show, setShow] = useState(false);

  const [visible, setVisible] = React.useState(false);
  const openMenu = () => setVisible(true);

  const handleRegister = () => {

    register({
      name: name,
      email: email,
      genero: genero,
      role: role,
      password: password,
      lgpd: lgpd,
      data: data

    }).then( res => {

      if(res){

        Alert.alert('Atenção', 'Usuário Cadastrado com sucesso!',[
          { text: "OK", onPress: () => navigation.goBack() }
        ]);

      }else{

         Alert.alert('Atenção', 'Usuário não cadastrado! Tente novamente mais tarde =D');
      }

    });
    
  }

  return (
    <Container>
      <View style={styles.header}>

      </View>

      <Headline style={styles.textHeader}>Nome do Projeto</Headline>


      <Input
          label="Nome"
          theme={{ colors: { primary: '#191970'}}}
          keyboardType="defalt"
          value={name}
          onChangeText={(text) => setName(text)}
          left={<TextInput.Icon name="account" style={{  marginTop: "50%" }} />}
        />


        {show && (
          <DateTimePicker
            testID="dateTimePicker"
            value={date}
            mode={'date'}
            is24Hour={true}
            display="default"
            onTouchCancel={() => setShow(false)}
            onChange={(event, date) => {
              setShow(false);
              setData(moment(date).format('DD/MM/YYYY'));
            }}
          />
        )}
        <TouchableOpacity onPress={() => setShow(true)}>
          <Input
            label="Data de nascimento"
            theme={{ colors: { primary: '#191970'}}}
            value={data}
            left={<TextInput.Icon name="calendar" />}
            editable={false}
          />
        </TouchableOpacity>
        

        <Input
          label="Email" 
          theme={{ colors: { primary: '#191970'}}}
          keyboardType="email-address"
          value={email}
          onChangeText={(text) => setEmail(text)}
          left={<TextInput.Icon name="email" style={{  marginTop: "50%" }} />}
        />
        <View 
            style= {styles.container}>
          <View 
            style={{ marginLeft: '10%'}}>
           <RadioButton
            color= "red"
            value={genero}
            status={  genero === 'Feminino' ? 'checked' : 'unchecked' }
            onPress={() => setGenero('feminino')}/>
            </View><Text style={styles.text}>Mulher</Text>
          <View style= {styles.container}>
           <RadioButton
           color= "red"
           value={genero}
           status={ genero === 'Masculino' ? 'checked' : 'unchecked' }
           onPress={() => setGenero('masculino')}
           style={styles.button}/>
          </View><Text style={styles.text}>Homem</Text>
          <View style= {styles.container}>
           <RadioButton
           color= "red"
           value={genero}
           status={ genero === 'Outro' ? 'checked' : 'unchecked' }
           onPress={() => {setGenero('masculino');
           setLgpd(true)}}
           style={styles.button}/>
          </View><Text style={styles.text}>Outros</Text>
        </View>
      
        <Input
          label="Senha"
          theme={{ colors: { primary: '#191970'}}}
          keyboardType="defalt"
          value={password}
          secureTextEntry={hidePass ? true : false}
          onChangeText={(text) => setPassword(text)}
          left={<TextInput.Icon name="key" style={{  marginTop: "50%" }}/>}
          right={<TextInput.Icon   
          name={hidePass ? 'eye-off' : 'eye'}
          onPress={() => setHidePass(!hidePass)}
          style={{  marginTop: "50%" }}/>}
        />
        <Provider>
      <View>
        <Menu
          style={{  marginHorizontal: '30%', marginBottom:'20%'}}
          visible={visible}
          anchor={<Button onPress={openMenu} ><Text style={styles.text}>Role</Text></Button>}>
          <Menu.Item onPress={() => { setRole('Admin');
            setVisible(false)}} title="Administrador" />
          <Divider />
          <Menu.Item onPress={() => { setRole('Professor');
            setVisible(false)}} title="Professor" />
          <Divider />
          <Menu.Item onPress={() => { setRole('Aluno');
            setVisible(false)}} title="Aluno" />
        </Menu>
      </View>
    </Provider>
        

        <Button
          style={styles.button}
          mode="contained"
          color= "#191970"
          onPress={handleRegister}>
          REGISTRAR
        </Button>
        <Button
          style={styles.button}

          mode="outlined"
          color= "red"
          onPress={() => navigation.goBack()}>
          Cancelar
        </Button>
    </Container>
  );
};

const styles = StyleSheet.create({
  button: {
    marginBottom: 12,
    borderRadius: 5,
    marginHorizontal: '10%',
    width: '80%',
    fontWeight: 'bold',
  },
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    color: '#191970',
    textShadowcolor: 'red'
  },
  textHeader: {
    marginBottom: '30%',
    textAlign: 'center',
    marginTop:'30%',
    color: "#191970",
  },
  header: {
    alignItems: 'center',
    marginTop: 30,
    marginBottom: 12
  },
  text:{
    color: '#191970',
    fontWeight: 'bold',
  },
});



export default Register;